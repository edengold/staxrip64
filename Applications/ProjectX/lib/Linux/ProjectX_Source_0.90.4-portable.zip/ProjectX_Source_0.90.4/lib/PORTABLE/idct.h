#include <math.h>

#ifndef __idct_h__
# define __idct_h__ 1
void IDCT_reference(short *);
void IDCT_test(short *,short*); // in -> out
void IDCT_init(void);
#endif


#!/bin/bash
if [ -z "$JAVA_HOME" ]; then
	echo Set your JAVA_HOME environment variable!
	exit 1
fi

if [ -z "$PROJECTX_HOME" ]; then
	if [ -f ../../ProjectX.jar ]; then
		echo Setting PROJECTX_HOME...
		pushd ../..
		export PROJECTX_HOME=`pwd`
		popd
		echo PROJECTX_HOME=$PROJECTX_HOME
	else
		echo Set your PROJECTX_HOME environment variable!
		echo to the directory where ProjectX.jar is
		exit 1
	fi
fi
make $*
if [ -f libidctfast.so ]; then
	echo Installing libidctfast.so
	cp -v libidctfast.so $PROJECTX_HOME/lib
fi

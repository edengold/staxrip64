#include <math.h>

#ifndef __idct_h__
# define __idct_h__ 1
void IDCT_reference(short *block);
void IDCT_init(void);
#endif

